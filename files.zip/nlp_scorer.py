# ============================================================
# DIGISHIELD — nlp_scorer.py
# Model:  distilbert-base-multilingual-cased
# Device: auto-detected (CUDA if available, CPU if not)
#
# What this file does:
#   1. Fine-tunes DistilBERT on YOUR labelled CSV
#      (text, label columns — label 1=scam, 0=not scam)
#   2. Saves checkpoint → model_artifacts/bert_finetuned/
#   3. Scores each incoming transcript chunk at runtime
#   4. Extracts which phrases BERT attended to most (explainability)
#
# What this file does NOT do:
#   - Generate synthetic training data (you supply real labels via CSV)
#   - Fall back to TF-IDF (BERT only)
#   - Use a benign phrase list (not needed for inference)
#
# Install:
#   pip install transformers torch accelerate sentencepiece
#               scikit-learn pandas numpy
# ============================================================

import json
import logging
import re
import threading
from pathlib import Path
from typing import Optional

import numpy as np
import torch

logger = logging.getLogger("digishield.nlp")
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
)

# ─── Paths ───────────────────────────────────────────────────
MODEL_DIR     = Path("model_artifacts")
BERT_SAVE_DIR = MODEL_DIR / "bert_finetuned"
METRICS_PATH  = MODEL_DIR / "metrics.json"
MODEL_DIR.mkdir(exist_ok=True)

# ─── BERT Config ─────────────────────────────────────────────
BERT_MODEL_NAME = "distilbert-base-multilingual-cased"
MAX_TOKEN_LEN   = 128

# ─── Risk Thresholds ─────────────────────────────────────────
THRESHOLDS = {"critical": 0.80, "high": 0.60, "medium": 0.35}

# ─── Scam Phrase Lexicon ─────────────────────────────────────
# ONLY used for attention-based phrase highlighting in the UI.
# Has NO role in training or classification — that is entirely
# handled by your labelled data and the BERT model weights.
SCAM_PHRASES = [
    # Authority impersonation
    "digital arrest", "you are under arrest", "warrant issued",
    "cbi officer", "enforcement directorate", "narcotics bureau",
    "customs department", "cyber crime department", "supreme court",
    "police commissioner", "central bureau investigation",
    # Identity / account threats
    "aadhaar illegal", "aadhaar misused", "aadhaar linked to crime",
    "pan card fraud", "your account is frozen", "bank account seized",
    "account suspended", "illegal transaction", "account blocked",
    # Coercion tactics
    "do not disconnect", "stay on the call", "do not tell anyone",
    "do not inform family", "remain on the line", "you cannot leave",
    "digital custody", "virtual arrest", "you are being monitored",
    "this call is being recorded by cbi",
    # Money demands
    "pay immediately", "transfer money", "send money now",
    "deposit to clear case", "pay to avoid arrest", "settlement amount",
    "case will be closed after payment", "clear your name by paying",
    "refundable security deposit",
    # Hindi transliterated
    "giraftari", "fir darj", "digital giraftari", "case band karo",
    "abhi payment karo", "turant paisa bhejo", "aapko arrest kiya jayega",
    "aap digital arrest mein hain", "warrant aa gaya hai",
    # General threat markers
    "illegal activities", "money laundering", "drug trafficking",
    "non bailable warrant", "arrest warrant", "serious charges",
    "criminal case registered",
]


# ─── Text Cleaning ────────────────────────────────────────────

def clean(text: str) -> str:
    """
    Minimal cleaning applied to every chunk before tokenisation.
    Preserves Devanagari (Hindi) characters and scam-specific terms.
    Avoids aggressive stemming — scam phrases are highly specific.
    """
    text = text.strip()
    text = re.sub(r'\s+', ' ', text)
    text = re.sub(r'[^\w\s\u0900-\u097F.,!?-]', ' ', text)
    return text.lower()


# ─── Risk Level Helper ────────────────────────────────────────

def _level(score: float) -> str:
    if score >= THRESHOLDS["critical"]: return "critical"
    if score >= THRESHOLDS["high"]:     return "high"
    if score >= THRESHOLDS["medium"]:   return "medium"
    return "safe"


# ─── Device Detection ─────────────────────────────────────────

def detect_device() -> torch.device:
    """
    Returns CUDA if available, CPU otherwise.
    Logs GPU name and VRAM so you can spot OOM risks early.

    Memory footprint when both models are running:
      faster-whisper small  ≈ 1.0 GB VRAM
      DistilBERT inference  ≈ 0.5 GB VRAM
      DistilBERT fine-tune  ≈ 2.5 GB VRAM (batch=16)
    """
    if torch.cuda.is_available():
        device   = torch.device("cuda")
        gpu_name = torch.cuda.get_device_name(0)
        vram_gb  = torch.cuda.get_device_properties(0).total_memory / 1e9
        logger.info(f"Device: CUDA — {gpu_name} ({vram_gb:.1f} GB VRAM)")
    else:
        device = torch.device("cpu")
        logger.info("Device: CPU (CUDA not available)")
    return device


# ══════════════════════════════════════════════════════════════
# BERT SCORER
# ══════════════════════════════════════════════════════════════

class BERTScorer:
    """
    Binary scam classifier using distilbert-base-multilingual-cased.

    Training:
        Your CSV  →  clean()  →  tokenise  →  fine-tune  →  checkpoint

    Inference per chunk (called every ~4 seconds during a live call):
        raw text
          → clean()
          → tokenise (max_length=128)
          → DistilBERT forward pass
          → softmax([P(not_scam), P(scam)])
          → attention-based phrase extraction
          → duration amplifier
          → rolling 5-chunk average
          → risk_level + flagged_phrases

    Public API:
        scorer = BERTScorer()
        scorer.load(csv_path="your_data.csv")   # fine-tune or load checkpoint
        result = scorer.score(text, call_duration_mins=5.0)
        scorer.reset_buffer()                    # call at each new session start
    """

    def __init__(self):
        self._model      = None
        self._tokenizer  = None
        self._device     = None
        self._loaded     = False
        self._lock       = threading.Lock()
        self._score_buffer: list[float] = []
        self._buffer_size = 5

    # ─── Load / Fine-tune ─────────────────────────────────────

    def load(
        self,
        csv_path: Optional[str] = None,
        force_retrain: bool = False,
    ) -> None:
        """
        Load or fine-tune the BERT model.

        Args:
            csv_path:      Path to your labelled CSV.
                           Required if no checkpoint exists yet.
                           Columns: text (str), label (int: 0 or 1)
            force_retrain: If True, ignores existing checkpoint and
                           retrains from scratch on csv_path.

        Behaviour:
            checkpoint exists + force_retrain=False → load directly (seconds)
            no checkpoint, csv_path provided        → fine-tune + save
            no checkpoint, no csv_path              → RuntimeError

        Raises:
            RuntimeError if transformers not installed, or if no checkpoint
            exists and no csv_path is provided.
        """
        with self._lock:
            if self._loaded and not force_retrain:
                return

            try:
                from transformers import (
                    AutoTokenizer,
                    AutoModelForSequenceClassification,
                )
            except ImportError:
                raise RuntimeError(
                    "transformers not installed.\n"
                    "Run: pip install transformers accelerate sentencepiece"
                )

            self._device = detect_device()

            # ── Load existing checkpoint ──────────────────────
            if BERT_SAVE_DIR.exists() and not force_retrain:
                logger.info(f"Loading checkpoint from {BERT_SAVE_DIR} ...")
                self._tokenizer = AutoTokenizer.from_pretrained(
                    str(BERT_SAVE_DIR)
                )
                self._model = AutoModelForSequenceClassification.from_pretrained(
                    str(BERT_SAVE_DIR)
                )
                logger.info("Checkpoint loaded.")

            # ── Fine-tune from scratch ────────────────────────
            else:
                if csv_path is None:
                    raise RuntimeError(
                        "No fine-tuned checkpoint found at "
                        f"'{BERT_SAVE_DIR}'.\n"
                        "Provide csv_path= to fine-tune from your labelled data."
                    )

                logger.info(
                    f"Downloading {BERT_MODEL_NAME} and fine-tuning "
                    f"on {csv_path} ..."
                )
                self._tokenizer = AutoTokenizer.from_pretrained(BERT_MODEL_NAME)
                self._model = AutoModelForSequenceClassification.from_pretrained(
                    BERT_MODEL_NAME,
                    num_labels=2,
                    ignore_mismatched_sizes=True,
                )
                self._model.to(self._device)

                df = self._load_csv(csv_path)
                self._fine_tune(df)

                # Save checkpoint for instant future loads
                BERT_SAVE_DIR.mkdir(parents=True, exist_ok=True)
                self._model.save_pretrained(str(BERT_SAVE_DIR))
                self._tokenizer.save_pretrained(str(BERT_SAVE_DIR))
                logger.info(f"Checkpoint saved → {BERT_SAVE_DIR}")

            self._model.to(self._device)
            self._model.eval()
            self._loaded = True
            logger.info(
                f"BERTScorer ready | device={self._device} | "
                f"model={BERT_MODEL_NAME}"
            )

    # ─── CSV Loading ──────────────────────────────────────────

    @staticmethod
    def _load_csv(csv_path: str):
        """
        Loads and validates your labelled CSV.

        Expected format:
            text                                    label
            "Your Aadhaar is linked to crime..."    1
            "Your order has been dispatched..."     0

        Validates:
            - Required columns exist
            - Labels are exactly 0 and 1
            - No empty text rows
            - Logs class distribution so you can spot imbalance
        """
        import pandas as pd

        df = pd.read_csv(csv_path)

        # Column check
        missing = [c for c in ["text", "label"] if c not in df.columns]
        if missing:
            raise ValueError(
                f"CSV missing columns: {missing}. "
                f"Found: {list(df.columns)}"
            )

        # Clean
        df["text"]  = df["text"].fillna("").astype(str).apply(clean)
        df["label"] = df["label"].astype(int)

        # Drop empty rows
        before = len(df)
        df = df[df["text"].str.len() >= 5].reset_index(drop=True)
        if len(df) < before:
            logger.warning(f"Dropped {before - len(df)} empty/short rows.")

        # Label validation
        unique_labels = set(df["label"].unique())
        if not unique_labels.issubset({0, 1}):
            raise ValueError(
                f"Labels must be 0 or 1. Found: {unique_labels}"
            )

        # Class distribution
        counts = df["label"].value_counts().to_dict()
        logger.info(
            f"Dataset loaded: {len(df)} rows | "
            f"scam(1)={counts.get(1,0)} | not_scam(0)={counts.get(0,0)}"
        )

        return df

    # ─── Fine-tuning ──────────────────────────────────────────

    def _fine_tune(
        self,
        df,
        epochs: int     = 3,
        batch_size: int = 16,
        lr: float       = 2e-5,
    ) -> None:
        """
        Fine-tunes DistilBERT on your binary-labelled dataset.

        Hyperparameter rationale:
        ─────────────────────────────────────────────────────────
        lr=2e-5
            Standard BERT fine-tuning rate. Higher → instability.
            Lower → underfitting on a small dataset.

        epochs=3
            Sufficient for most datasets. Best epoch is kept via
            early stopping on val F1, so extra epochs don't hurt.

        batch_size=16
            Safe on 6GB VRAM alongside Whisper small (~3.5GB total).
            Reduce to 8 if you get CUDA OOM during fine-tuning.

        warmup_ratio=0.1
            Linear LR warmup for 10% of steps — prevents large gradient
            updates from destabilising pre-trained weights early on.

        weight_decay=0.01
            L2 regularisation on all non-bias parameters.

        grad_clip=1.0
            Standard gradient clipping for transformer fine-tuning.

        class_weight="balanced"
            Compensates automatically for label imbalance in your CSV.
            If your data is already 50/50 this has no effect.
        ─────────────────────────────────────────────────────────
        """
        from torch.optim import AdamW
        from torch.utils.data import DataLoader, TensorDataset
        from transformers import get_linear_schedule_with_warmup
        from sklearn.model_selection import train_test_split
        from sklearn.metrics import (
            f1_score, classification_report
        )
        from sklearn.utils.class_weight import compute_class_weight

        texts  = df["text"].tolist()
        labels = df["label"].tolist()

        logger.info(f"Tokenising {len(texts)} examples ...")
        enc = self._tokenizer(
            texts,
            padding="max_length",
            truncation=True,
            max_length=MAX_TOKEN_LEN,
            return_tensors="pt",
        )
        input_ids      = enc["input_ids"]       # [N, 128]
        attention_mask = enc["attention_mask"]   # [N, 128]
        label_tensor   = torch.tensor(labels, dtype=torch.long)

        # 85 / 15 train / val split
        n     = len(texts)
        split = int(n * 0.85)
        perm  = torch.randperm(n)
        tr_i, va_i = perm[:split], perm[split:]

        train_loader = DataLoader(
            TensorDataset(
                input_ids[tr_i],
                attention_mask[tr_i],
                label_tensor[tr_i],
            ),
            batch_size=batch_size,
            shuffle=True,
        )
        val_loader = DataLoader(
            TensorDataset(
                input_ids[va_i],
                attention_mask[va_i],
                label_tensor[va_i],
            ),
            batch_size=64,
        )

        # Optimiser + linear warmup scheduler
        optimiser   = AdamW(
            self._model.parameters(), lr=lr, weight_decay=0.01
        )
        total_steps = len(train_loader) * epochs
        scheduler   = get_linear_schedule_with_warmup(
            optimiser,
            num_warmup_steps=int(total_steps * 0.1),
            num_training_steps=total_steps,
        )

        # Weighted cross-entropy — handles class imbalance automatically
        cw = compute_class_weight(
            "balanced", classes=np.array([0, 1]), y=labels
        )
        loss_fn = torch.nn.CrossEntropyLoss(
            weight=torch.tensor(cw, dtype=torch.float).to(self._device)
        )

        best_f1    = 0.0
        best_state = None

        for epoch in range(epochs):

            # ── Train ─────────────────────────────────────────
            self._model.train()
            epoch_loss = 0.0

            for batch in train_loader:
                ids, mask, lbl = [b.to(self._device) for b in batch]
                optimiser.zero_grad()
                out  = self._model(input_ids=ids, attention_mask=mask)
                loss = loss_fn(out.logits, lbl)
                loss.backward()
                torch.nn.utils.clip_grad_norm_(
                    self._model.parameters(), max_norm=1.0
                )
                optimiser.step()
                scheduler.step()
                epoch_loss += loss.item()

            # ── Validate ──────────────────────────────────────
            self._model.eval()
            all_preds, all_labels = [], []

            with torch.no_grad():
                for batch in val_loader:
                    ids, mask, lbl = [b.to(self._device) for b in batch]
                    out   = self._model(input_ids=ids, attention_mask=mask)
                    preds = out.logits.argmax(dim=-1)
                    all_preds.extend(preds.cpu().numpy())
                    all_labels.extend(lbl.cpu().numpy())

            val_f1 = f1_score(all_labels, all_preds, zero_division=0)
            logger.info(
                f"Epoch {epoch + 1}/{epochs} | "
                f"loss={epoch_loss / len(train_loader):.4f} | "
                f"val_F1={val_f1:.4f}"
            )

            # Keep best epoch (early stopping proxy)
            if val_f1 > best_f1:
                best_f1    = val_f1
                best_state = {
                    k: v.clone()
                    for k, v in self._model.state_dict().items()
                }

        # Restore best epoch weights
        if best_state:
            self._model.load_state_dict(best_state)

        # Final classification report
        self._model.eval()
        all_preds, all_labels = [], []
        with torch.no_grad():
            for batch in val_loader:
                ids, mask, lbl = [b.to(self._device) for b in batch]
                out   = self._model(input_ids=ids, attention_mask=mask)
                preds = out.logits.argmax(dim=-1)
                all_preds.extend(preds.cpu().numpy())
                all_labels.extend(lbl.cpu().numpy())

        logger.info(
            "\n" + classification_report(
                all_labels, all_preds,
                target_names=["not_scam (0)", "scam (1)"],
                zero_division=0,
            )
        )

        # Save metrics
        metrics = {
            "f1":     round(best_f1, 4),
            "model":  BERT_MODEL_NAME,
            "epochs": epochs,
            "device": str(self._device),
        }
        METRICS_PATH.write_text(json.dumps(metrics, indent=2))
        logger.info(f"Fine-tuning complete — best val F1={best_f1:.4f}")

    # ─── Inference ────────────────────────────────────────────

    def score(
        self,
        text: str,
        call_duration_mins: float = 0.0,
    ) -> dict:
        """
        Score one transcript chunk (called every ~4 seconds).

        Args:
            text:               Transcribed text from faster-whisper.
            call_duration_mins: Current call length in minutes.
                                Long calls with elevated scores get
                                a small risk amplification.
        Returns:
            {
              "raw_score":       float,  # P(scam) for this chunk
              "smoothed_score":  float,  # rolling 5-chunk average
              "risk_level":      str,    # safe|medium|high|critical
              "flagged_phrases": list,   # attention-highlighted phrases
              "model_used":      str,
              "device":          str,
            }
        """
        if not self._loaded:
            raise RuntimeError(
                "BERTScorer not loaded. Call scorer.load() first."
            )

        cleaned = clean(text)

        enc = self._tokenizer(
            cleaned,
            padding="max_length",
            truncation=True,
            max_length=MAX_TOKEN_LEN,
            return_tensors="pt",
        )
        input_ids      = enc["input_ids"].to(self._device)
        attention_mask = enc["attention_mask"].to(self._device)

        with torch.no_grad():
            out = self._model(
                input_ids=input_ids,
                attention_mask=attention_mask,
                output_attentions=True,
            )

        # Softmax → index 1 = P(scam), index 0 = P(not_scam)
        probs     = torch.softmax(out.logits, dim=-1)[0]
        raw_score = float(probs[1].cpu())

        # Attention-based phrase extraction (explainability only)
        flagged = self._attention_phrases(enc, out.attentions)

        # Duration amplifier
        if call_duration_mins > 20:
            raw_score = min(raw_score * 1.15, 1.0)
        elif call_duration_mins > 10:
            raw_score = min(raw_score * 1.08, 1.0)

        # Rolling 5-chunk average — smooths Whisper mishearing noise
        self._score_buffer.append(raw_score)
        if len(self._score_buffer) > self._buffer_size:
            self._score_buffer.pop(0)
        smoothed = float(np.mean(self._score_buffer))

        return {
            "raw_score":       round(raw_score, 4),
            "smoothed_score":  round(smoothed,  4),
            "risk_level":      _level(smoothed),
            "flagged_phrases": flagged,
            "model_used":      "distilbert-multilingual",
            "device":          str(self._device),
        }

    # ─── Attention-based Phrase Extraction ────────────────────

    def _attention_phrases(self, enc, attentions) -> list[str]:
        """
        Identifies which scam phrases BERT attended to most.
        Pure UI explainability — does not affect the risk score.

        Steps:
          1. Last transformer layer attention: [heads, seq, seq]
          2. Average across heads → [seq, seq]
          3. Row 0 = [CLS] attention over input tokens
          4. Tokens where attention > mean + 1×std → "high attention"
          5. Decode → strip wordpiece "##" prefix → skip special tokens
          6. Match decoded tokens against SCAM_PHRASES lexicon
          7. Return matched phrases, or raw hot tokens if none matched
        """
        try:
            last_layer = attentions[-1][0]       # [heads, seq, seq]
            avg_heads  = last_layer.mean(dim=0)  # [seq, seq]
            cls_attn   = avg_heads[0].cpu().numpy()  # [seq]

            threshold = cls_attn.mean() + cls_attn.std()
            hot_idx   = np.where(cls_attn > threshold)[0]

            tokens  = self._tokenizer.convert_ids_to_tokens(
                enc["input_ids"][0]
            )
            special = {
                "[CLS]", "[SEP]", "[PAD]",
                "<s>", "</s>", "[UNK]", "<pad>",
            }
            hot_tokens = []
            for i in hot_idx:
                tok = tokens[i].lstrip("##").lower()
                if tok not in special and len(tok) > 2:
                    hot_tokens.append(tok)

            if not hot_tokens:
                return []

            hot_text = " ".join(hot_tokens)
            matched  = [
                phrase for phrase in SCAM_PHRASES
                if any(word in hot_text for word in phrase.split())
            ]

            return (matched if matched else hot_tokens)[:8]

        except Exception as e:
            logger.debug(f"Attention extraction failed: {e}")
            return []

    # ─── Utilities ────────────────────────────────────────────

    def reset_buffer(self) -> None:
        """Clear rolling score buffer. Call at the start of each session."""
        self._score_buffer.clear()

    @property
    def is_loaded(self) -> bool:
        return self._loaded

    @property
    def device_str(self) -> str:
        return str(self._device) if self._device else "not loaded"


# ─── Module-level singleton ───────────────────────────────────
# Streamlit imports modules once per server process.
# Singleton persists across reruns — model stays in GPU/CPU memory.

_scorer: Optional[BERTScorer] = None
_scorer_lock = threading.Lock()


def get_scorer() -> BERTScorer:
    """Return the shared BERTScorer instance (creates if needed)."""
    global _scorer
    if _scorer is None:
        with _scorer_lock:
            if _scorer is None:
                _scorer = BERTScorer()
    return _scorer
