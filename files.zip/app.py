# ============================================================
# DIGISHIELD — app.py
# Main Streamlit web application.
#
# Architecture:
#   • stt_core.py   → background threads (your audio code)
#   • nlp_scorer.py → DistilBERT multilingual scorer (BERT only)
#   • app.py        → Streamlit UI, reads from TranscriptBus
#
# Run:
#   streamlit run app.py
#
# Install deps:
#   pip install streamlit faster-whisper soundcard sounddevice
#               transformers accelerate sentencepiece torch
#               scikit-learn pandas numpy plotly
# ============================================================

import time
import json
from datetime import datetime
from pathlib import Path
from collections import deque
from typing import Optional

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
import streamlit as st

from stt_core import STTSession
from nlp_scorer import get_scorer, THRESHOLDS, BERT_MODEL_NAME

# ─── Page Config (must be first Streamlit call) ───────────────
st.set_page_config(
    page_title="DIGISHIELD — Scam Detection",
    page_icon="🛡️",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ─── Global CSS ───────────────────────────────────────────────
st.markdown("""
<style>
/* ── Base dark theme ── */
.stApp { background-color: #0d1b2a; color: #e0e0e0; }
section[data-testid="stSidebar"] { background-color: #111f2e; }

/* ── Risk level cards ── */
.risk-safe     { background:#0a2e14; border:2px solid #4caf50;
                 border-radius:14px; padding:18px; text-align:center; }
.risk-medium   { background:#2e2600; border:2px solid #ffc107;
                 border-radius:14px; padding:18px; text-align:center; }
.risk-high     { background:#2e1500; border:2px solid #ff9800;
                 border-radius:14px; padding:18px; text-align:center; }
.risk-critical { background:#2e0000; border:2px solid #f44336;
                 border-radius:14px; padding:18px; text-align:center;
                 animation: pulse 1s infinite; }

@keyframes pulse {
    0%   { box-shadow: 0 0 0   0 rgba(244,67,54,0.6); }
    70%  { box-shadow: 0 0 0 12px rgba(244,67,54,0);   }
    100% { box-shadow: 0 0 0   0 rgba(244,67,54,0);    }
}

/* ── Transcript bubbles ── */
.bubble-system { background:#1a2e40; border-left:4px solid #2e75b6;
                 padding:10px 14px; border-radius:8px;
                 margin:4px 0; font-size:14px; }
.bubble-mic    { background:#1a2e1a; border-left:4px solid #4caf50;
                 padding:10px 14px; border-radius:8px;
                 margin:4px 0; font-size:14px; }
.bubble-scam   { background:#2e1000; border-left:4px solid #ff5722;
                 padding:10px 14px; border-radius:8px;
                 margin:4px 0; font-size:14px; }

/* ── Alert banner ── */
.alert-banner  { background:#2e0000; border:2px solid #f44336;
                 border-radius:12px; padding:20px;
                 text-align:center; margin:12px 0; }

/* ── Phrase chip ── */
.phrase-chip   { display:inline-block; background:#3d1a00;
                 color:#ff9800; border:1px solid #ff9800;
                 border-radius:20px; padding:3px 12px;
                 font-size:12px; margin:3px; }

/* ── Metric box ── */
.metric-box    { background:#1a2e40; border:1px solid #2e75b6;
                 border-radius:10px; padding:14px;
                 text-align:center; }

/* ── Section header ── */
h2 { color:#2e75b6 !important; }
h3 { color:#64b5f6 !important; }
</style>
""", unsafe_allow_html=True)


# ─── Session State Bootstrap ──────────────────────────────────
# All mutable state lives here — survives Streamlit reruns.

def init_state():
    defaults = {
        # STT
        "stt_session":       None,
        "monitoring":        False,
        # Transcripts: list of {"source", "text", "ts", "risk_level", "score", "phrases"}
        "transcript_log":    [],
        # Risk history for chart: list of {"ts", "score"}
        "risk_history":      deque(maxlen=120),  # 120 × 4s = ~8 min
        # Current aggregate risk
        "current_score":     0.0,
        "current_level":     "safe",
        "current_phrases":   [],
        # Session stats
        "session_start":     None,
        "alert_count":       {"critical": 0, "high": 0, "medium": 0},
        # Settings
        "consent_given":     False,
        "trusted_contact":   "",
        "call_start_time":   None,
        # Model loading state
        "model_loaded":      False,
        "model_loading":     False,
        "model_device":      "unknown",
        # Auto-refresh flag
        "last_refresh":      0.0,
    }
    for k, v in defaults.items():
        if k not in st.session_state:
            st.session_state[k] = v

init_state()


# ─── Helpers ──────────────────────────────────────────────────

LEVEL_COLORS = {
    "safe":     "#4caf50",
    "medium":   "#ffc107",
    "high":     "#ff9800",
    "critical": "#f44336",
}
LEVEL_ICONS  = {
    "safe": "✅", "medium": "🟡", "high": "🟠", "critical": "🔴"
}

def level_to_class(level: str) -> str:
    return f"risk-{level}"

def fmt_score(score: float) -> str:
    return f"{score * 100:.1f}%"

def fmt_time(ts: float) -> str:
    return datetime.fromtimestamp(ts).strftime("%H:%M:%S")

def call_duration_mins() -> float:
    if st.session_state.call_start_time is None:
        return 0.0
    return (time.time() - st.session_state.call_start_time) / 60.0


# ─── Core Update Loop ─────────────────────────────────────────
# Called on every Streamlit rerun. Drains the transcript bus,
# scores new chunks, updates session state.

def process_new_transcripts():
    stt: STTSession = st.session_state.stt_session
    if stt is None or not st.session_state.monitoring:
        return

    new_items = stt.bus.drain()
    if not new_items:
        return

    scorer = get_scorer()

    for item in new_items:
        result = scorer.score(
            text=item["text"],
            call_duration_mins=call_duration_mins(),
        )

        # Enrich the transcript item with scoring info
        enriched = {
            **item,
            "score":     result["smoothed_score"],
            "risk_level": result["risk_level"],
            "phrases":   result["flagged_phrases"],
        }
        st.session_state.transcript_log.append(enriched)

        # Update risk history chart data
        st.session_state.risk_history.append({
            "ts":    item["ts"],
            "score": result["smoothed_score"],
            "level": result["risk_level"],
        })

        # Update current risk state
        st.session_state.current_score   = result["smoothed_score"]
        st.session_state.current_level   = result["risk_level"]
        st.session_state.current_phrases = result["flagged_phrases"]

        # Increment alert counters
        lvl = result["risk_level"]
        if lvl in st.session_state.alert_count:
            st.session_state.alert_count[lvl] += 1

    # Cap transcript log to last 200 entries
    if len(st.session_state.transcript_log) > 200:
        st.session_state.transcript_log = st.session_state.transcript_log[-200:]


# ─── Sidebar ──────────────────────────────────────────────────

def render_sidebar():
    with st.sidebar:
        st.markdown("## 🛡️ DIGISHIELD")
        st.caption("Digital Arrest Scam Detection")
        st.divider()

        # ── Navigation ──────────────────────────────────────
        page = st.radio(
            "Navigate",
            ["🔴 Live Monitor", "📊 Analytics", "⚙️ Settings", "ℹ️ About"],
            label_visibility="collapsed",
        )

        st.divider()

        # ── Quick Status ─────────────────────────────────────
        if st.session_state.monitoring:
            st.success("● Monitoring ACTIVE")
            dur = call_duration_mins()
            st.caption(f"Duration: {int(dur)}m {int((dur % 1)*60)}s")

            # Mic toggle
            stt: STTSession = st.session_state.stt_session
            if stt:
                mic_label = "🎤 Mic: ON" if stt.mic_is_on else "🔇 Mic: OFF"
                if st.button(mic_label, use_container_width=True):
                    stt.toggle_mic()
                    st.rerun()
        else:
            st.info("○ Not monitoring")

        st.divider()

        # ── Model Status Badge ───────────────────────────────
        if st.session_state.get("model_loaded"):
            device = st.session_state.get("model_device", "cpu")
            device_icon = "⚡" if "cuda" in device else "🖥️"
            st.markdown(
                f'<div style="background:#0a2e14;border:1px solid #4caf50;'
                f'border-radius:8px;padding:8px;text-align:center;font-size:12px;">'
                f'🧠 <b style="color:#4caf50">BERT Active</b><br>'
                f'<span style="color:#aaa">distilbert-multilingual</span><br>'
                f'<span style="color:#4caf50">{device_icon} {device.upper()}</span>'
                f'</div>',
                unsafe_allow_html=True,
            )
        elif st.session_state.get("model_loading"):
            st.markdown(
                '<div style="background:#1a2e40;border:1px solid #2e75b6;'
                'border-radius:8px;padding:8px;text-align:center;font-size:12px;">'
                '⏳ <b style="color:#2e75b6">Loading BERT...</b></div>',
                unsafe_allow_html=True,
            )
        else:
            st.markdown(
                '<div style="background:#1a1a1a;border:1px solid #555;'
                'border-radius:8px;padding:8px;text-align:center;font-size:12px;">'
                '○ <span style="color:#888">BERT not loaded yet</span></div>',
                unsafe_allow_html=True,
            )

        st.divider()
        lvl   = st.session_state.current_level
        score = st.session_state.current_score
        color = LEVEL_COLORS[lvl]
        icon  = LEVEL_ICONS[lvl]

        st.markdown(f"""
        <div style="text-align:center; padding:12px; border-radius:10px;
                    border:2px solid {color}; background:#111f2e;">
            <div style="font-size:28px">{icon}</div>
            <div style="font-size:22px; font-weight:bold; color:{color}">
                {lvl.upper()}
            </div>
            <div style="font-size:18px; color:#fff">
                {fmt_score(score)}
            </div>
        </div>
        """, unsafe_allow_html=True)

        # Auto-refresh toggle
        st.divider()
        auto_refresh = st.checkbox("Auto-refresh (3s)", value=True)
        if auto_refresh and st.session_state.monitoring:
            time.sleep(3)
            st.rerun()

    return page.split(" ", 1)[1]   # Strip emoji prefix


# ─── PAGE: Live Monitor ───────────────────────────────────────

def page_live_monitor():
    # Process any new transcripts from the STT bus
    process_new_transcripts()

    st.markdown("## 🔴 Live Call Monitor")

    # ── Consent gate ─────────────────────────────────────────
    if not st.session_state.consent_given:
        render_consent_gate()
        return

    # ── Start / Stop controls ─────────────────────────────────
    # CSV path only needed on first run (fine-tuning).
    # Once checkpoint exists, it's ignored.
    checkpoint_exists = (Path("model_artifacts") / "bert_finetuned").exists()

    if not checkpoint_exists and not st.session_state.model_loaded:
        st.info(
            "No fine-tuned checkpoint found. "
            "Provide your labelled CSV below to fine-tune BERT before monitoring."
        )
        csv_path_input = st.text_input(
            "Path to labelled CSV",
            placeholder="data/scam_transcripts.csv",
            help="CSV must have columns: text (str), label (int: 1=scam, 0=not scam)",
        )
    else:
        csv_path_input = None   # Checkpoint exists — no CSV needed

    col_start, col_stop, col_spacer = st.columns([2, 2, 6])

    with col_start:
        # Disable start if checkpoint missing and no CSV provided
        needs_csv    = not checkpoint_exists and not st.session_state.model_loaded
        start_ready  = not needs_csv or bool(csv_path_input)
        start_disabled = st.session_state.monitoring or not start_ready

        if st.button(
            "▶ Start Monitoring",
            disabled=start_disabled,
            use_container_width=True,
            type="primary",
        ):
            _start_monitoring(csv_path=csv_path_input or None)

    with col_stop:
        if st.button("⏹ Stop", disabled=not st.session_state.monitoring,
                     use_container_width=True):
            _stop_monitoring()

    st.divider()

    if not st.session_state.monitoring and not st.session_state.transcript_log:
        st.info("Press **▶ Start Monitoring** to begin real-time scam detection.")
        st.markdown("""
        **How it works:**
        1. DIGISHIELD captures your system audio (what you hear on a call)
        2. Whisper transcribes speech in real time
        3. Each chunk is scored by the NLP model
        4. Alerts fire if scam patterns are detected
        """)
        return

    # ── Critical Alert Banner ─────────────────────────────────
    if st.session_state.current_level == "critical":
        st.markdown("""
        <div class="alert-banner">
            <div style="font-size:32px">🚨</div>
            <div style="font-size:22px; font-weight:bold; color:#f44336">
                SCAM DETECTED — HIGH CONFIDENCE
            </div>
            <div style="color:#ffcdd2; margin-top:8px">
                Real police NEVER conduct arrests over phone calls.<br>
                Government agencies NEVER demand money to close cases.<br>
                <strong>Disconnect immediately and call 1930 (Cyber Crime Helpline).</strong>
            </div>
        </div>
        """, unsafe_allow_html=True)

    elif st.session_state.current_level == "high":
        st.warning(
            "⚠️ **HIGH RISK DETECTED** — This call shows signs of a digital arrest scam. "
            "Be cautious. You may disconnect at any time."
        )

    # ── Risk Meter Row ────────────────────────────────────────
    col_meter, col_stats = st.columns([3, 2])

    with col_meter:
        render_risk_gauge()

    with col_stats:
        render_session_stats()

    st.divider()

    # ── Flagged Phrases ───────────────────────────────────────
    phrases = st.session_state.current_phrases
    if phrases:
        st.markdown("#### 🔍 Triggering Phrases")
        chips = "".join(
            f'<span class="phrase-chip">{p}</span>' for p in phrases
        )
        st.markdown(chips, unsafe_allow_html=True)
        st.caption("These phrases contributed most to the current risk score.")

    # ── Risk Timeline Chart ───────────────────────────────────
    render_risk_timeline()

    st.divider()

    # ── Live Transcript Feed ──────────────────────────────────
    render_transcript_feed()


def render_consent_gate():
    st.markdown("### 🔐 Privacy Consent")
    st.info("DIGISHIELD requires your consent before processing any audio.")

    with st.expander("Read before continuing", expanded=True):
        st.markdown("""
        **What DIGISHIELD does:**
        - Captures audio from your system speakers (call audio you are already hearing)
        - Transcribes speech locally using the Whisper model — **no audio leaves your machine**
        - Analyses transcript text to detect scam patterns
        - Stores only anonymised risk scores — **no raw audio, no full transcripts saved**

        **What DIGISHIELD does NOT do:**
        - Record or save audio files
        - Send your voice or conversation to any external server
        - Share your data with third parties
        - Process audio without your explicit start action

        **Legal note:** You are processing audio that you are an active participant in
        receiving. This tool is for personal safety use only.
        """)

    col1, col2 = st.columns(2)
    with col1:
        trusted = st.text_input("Trusted contact phone (optional)",
                                placeholder="+91 9999999999",
                                help="For your records only — not sent anywhere.")
    with col2:
        st.markdown("<br>", unsafe_allow_html=True)
        if st.button("✅ I understand — Enable Protection",
                     use_container_width=True, type="primary"):
            st.session_state.consent_given = True
            st.session_state.trusted_contact = trusted
            st.rerun()


def render_risk_gauge():
    score = st.session_state.current_score
    level = st.session_state.current_level
    color = LEVEL_COLORS[level]

    # Plotly gauge chart
    fig = go.Figure(go.Indicator(
        mode="gauge+number",
        value=score * 100,
        number={"suffix": "%", "font": {"size": 36, "color": color}},
        gauge={
            "axis": {"range": [0, 100], "tickcolor": "#ffffff",
                     "tickfont": {"color": "#ffffff"}},
            "bar":  {"color": color},
            "bgcolor": "#1a2e40",
            "steps": [
                {"range": [0, 35],  "color": "#0a2e14"},
                {"range": [35, 60], "color": "#2e2600"},
                {"range": [60, 80], "color": "#2e1500"},
                {"range": [80, 100],"color": "#2e0000"},
            ],
            "threshold": {
                "line": {"color": "#ffffff", "width": 2},
                "thickness": 0.75,
                "value": score * 100,
            },
        },
        title={"text": f"{LEVEL_ICONS[level]} {level.upper()} RISK",
               "font": {"size": 18, "color": color}},
    ))
    fig.update_layout(
        paper_bgcolor="#0d1b2a",
        font_color="#ffffff",
        height=260,
        margin=dict(t=60, b=10, l=20, r=20),
    )
    st.plotly_chart(fig, use_container_width=True, key="gauge")


def render_session_stats():
    st.markdown("#### Session Stats")
    ac = st.session_state.alert_count

    c1, c2 = st.columns(2)
    with c1:
        st.metric("🔴 Critical", ac["critical"])
        st.metric("🟡 Medium",   ac["medium"])
    with c2:
        st.metric("🟠 High",     ac["high"])
        total = sum(ac.values())
        st.metric("Total Alerts", total)

    dur = call_duration_mins()
    st.caption(f"Call duration: {int(dur)}m {int((dur % 1)*60)}s")

    chunks = len(st.session_state.transcript_log)
    st.caption(f"Chunks analysed: {chunks}")

    if st.session_state.transcript_log:
        scores = [e["score"] for e in st.session_state.transcript_log]
        st.caption(f"Peak risk: {fmt_score(max(scores))}")


def render_risk_timeline():
    history = list(st.session_state.risk_history)
    if len(history) < 2:
        return

    st.markdown("#### 📈 Risk Score Timeline")

    df = pd.DataFrame(history)
    df["time"] = pd.to_datetime(df["ts"], unit="s").dt.strftime("%H:%M:%S")

    fig = go.Figure()

    # Shaded risk zones
    fig.add_hrect(y0=0,    y1=0.35, fillcolor="#0a2e14", opacity=0.3, line_width=0)
    fig.add_hrect(y0=0.35, y1=0.60, fillcolor="#2e2600", opacity=0.3, line_width=0)
    fig.add_hrect(y0=0.60, y1=0.80, fillcolor="#2e1500", opacity=0.3, line_width=0)
    fig.add_hrect(y0=0.80, y1=1.00, fillcolor="#2e0000", opacity=0.3, line_width=0)

    # Threshold lines
    for thresh, label, color in [
        (THRESHOLDS["medium"],   "Medium",   "#ffc107"),
        (THRESHOLDS["high"],     "High",     "#ff9800"),
        (THRESHOLDS["critical"], "Critical", "#f44336"),
    ]:
        fig.add_hline(y=thresh, line_dash="dash",
                      line_color=color, opacity=0.6,
                      annotation_text=label,
                      annotation_font_color=color)

    # Risk score line
    fig.add_trace(go.Scatter(
        x=df["time"], y=df["score"],
        mode="lines+markers",
        line=dict(color="#2e75b6", width=2),
        marker=dict(
            color=[LEVEL_COLORS[l] for l in df["level"]],
            size=7,
        ),
        fill="tozeroy",
        fillcolor="rgba(46,117,182,0.15)",
        name="Risk Score",
    ))

    fig.update_layout(
        paper_bgcolor="#0d1b2a",
        plot_bgcolor="#0d1b2a",
        font_color="#ffffff",
        height=240,
        margin=dict(t=20, b=40, l=50, r=20),
        xaxis=dict(showgrid=False, title="Time"),
        yaxis=dict(showgrid=False, title="Risk", range=[0, 1],
                   tickformat=".0%"),
        showlegend=False,
    )
    st.plotly_chart(fig, use_container_width=True, key="timeline")


def render_transcript_feed():
    st.markdown("#### 📝 Live Transcript Feed")
    st.caption(
        "🔵 System audio (what you're hearing) &nbsp;|&nbsp; "
        "🟢 Microphone (your voice) &nbsp;|&nbsp; "
        "🔶 High-risk chunk"
    )

    log = st.session_state.transcript_log
    if not log:
        st.caption("Transcript will appear here once monitoring starts...")
        return

    # Show last 30 entries, newest first
    for entry in reversed(log[-30:]):
        ts      = fmt_time(entry["ts"])
        source  = entry["source"]
        text    = entry["text"]
        level   = entry.get("risk_level", "safe")
        score   = entry.get("score", 0.0)

        # Pick bubble style
        if level in ("high", "critical"):
            bubble_class = "bubble-scam"
            prefix = f"[{ts}] [{source}] ⚠️ "
        elif source == "MIC":
            bubble_class = "bubble-mic"
            prefix = f"[{ts}] [MIC] "
        else:
            bubble_class = "bubble-system"
            prefix = f"[{ts}] [SYS] "

        score_tag = (
            f'<span style="float:right;color:{LEVEL_COLORS[level]};'
            f'font-size:11px;">{fmt_score(score)}</span>'
        )
        st.markdown(
            f'<div class="{bubble_class}">'
            f'{score_tag}'
            f'<span style="color:#888;font-size:11px;">{prefix}</span>'
            f'{text}'
            f'</div>',
            unsafe_allow_html=True,
        )

    # Export transcript button
    if st.button("📥 Export Transcript", use_container_width=False):
        rows = [
            {
                "time":       fmt_time(e["ts"]),
                "source":     e["source"],
                "text":       e["text"],
                "risk_level": e.get("risk_level", ""),
                "score":      e.get("score", 0.0),
            }
            for e in log
        ]
        df = pd.DataFrame(rows)
        csv = df.to_csv(index=False)
        st.download_button(
            label="Download CSV",
            data=csv,
            file_name=f"digishield_transcript_{datetime.now().date()}.csv",
            mime="text/csv",
        )


# ─── PAGE: Analytics ──────────────────────────────────────────

def page_analytics():
    st.markdown("## 📊 Session Analytics")

    log = st.session_state.transcript_log
    if not log:
        st.info("No session data yet. Run the Live Monitor first.")
        return

    df = pd.DataFrame([{
        "time":   fmt_time(e["ts"]),
        "source": e["source"],
        "score":  e.get("score", 0.0),
        "level":  e.get("risk_level", "safe"),
        "text":   e["text"],
    } for e in log])

    # ── KPI row ───────────────────────────────────────────────
    c1, c2, c3, c4 = st.columns(4)
    with c1: st.metric("Chunks Analysed",  len(df))
    with c2: st.metric("Avg Risk Score",   fmt_score(df["score"].mean()))
    with c3: st.metric("Peak Risk",        fmt_score(df["score"].max()))
    with c4:
        high_pct = (df["level"].isin(["high","critical"])).mean()
        st.metric("High-Risk Chunks", fmt_score(high_pct))

    st.divider()

    # ── Risk level breakdown ──────────────────────────────────
    col_a, col_b = st.columns(2)
    with col_a:
        st.markdown("#### Risk Level Breakdown")
        level_counts = df["level"].value_counts().reset_index()
        level_counts.columns = ["level", "count"]
        fig_pie = px.pie(
            level_counts, values="count", names="level",
            color="level",
            color_discrete_map={
                "safe":     "#4caf50", "medium": "#ffc107",
                "high":     "#ff9800", "critical":"#f44336",
            },
            hole=0.45,
        )
        fig_pie.update_layout(
            paper_bgcolor="#0d1b2a", font_color="#fff", height=280,
            margin=dict(t=20, b=10, l=10, r=10),
        )
        st.plotly_chart(fig_pie, use_container_width=True, key="pie")

    with col_b:
        st.markdown("#### Risk Score Distribution")
        fig_hist = px.histogram(
            df, x="score", nbins=20,
            color_discrete_sequence=["#2e75b6"],
            labels={"score": "Risk Score"},
        )
        for thresh, color in [
            (THRESHOLDS["medium"],   "#ffc107"),
            (THRESHOLDS["high"],     "#ff9800"),
            (THRESHOLDS["critical"], "#f44336"),
        ]:
            fig_hist.add_vline(x=thresh, line_dash="dash",
                               line_color=color, opacity=0.7)
        fig_hist.update_layout(
            paper_bgcolor="#0d1b2a", plot_bgcolor="#0d1b2a",
            font_color="#fff", height=280,
            margin=dict(t=20, b=10, l=10, r=10),
        )
        st.plotly_chart(fig_hist, use_container_width=True, key="hist")

    # ── Source breakdown ─────────────────────────────────────
    st.markdown("#### Audio Source Breakdown")
    src_counts = df.groupby("source")["score"].agg(
        chunks="count", avg_risk="mean", max_risk="max"
    ).reset_index()
    st.dataframe(src_counts.style.format({
        "avg_risk": "{:.1%}", "max_risk": "{:.1%}"
    }), use_container_width=True, hide_index=True)

    # ── Top flagged phrases ───────────────────────────────────
    st.markdown("#### Top Flagged Phrases")
    phrase_counts: dict[str, int] = {}
    for entry in log:
        for p in entry.get("phrases", []):
            phrase_counts[p] = phrase_counts.get(p, 0) + 1

    if phrase_counts:
        top = sorted(phrase_counts.items(), key=lambda x: x[1], reverse=True)[:12]
        phrase_df = pd.DataFrame(top, columns=["Phrase", "Count"])
        fig_bar = px.bar(
            phrase_df, x="Count", y="Phrase", orientation="h",
            color="Count", color_continuous_scale="Oranges",
        )
        fig_bar.update_layout(
            paper_bgcolor="#0d1b2a", plot_bgcolor="#0d1b2a",
            font_color="#fff", height=max(250, len(top) * 28),
            margin=dict(t=10, b=20, l=10, r=10),
            yaxis={"categoryorder": "total ascending"},
            showlegend=False,
        )
        st.plotly_chart(fig_bar, use_container_width=True, key="phrases")
    else:
        st.caption("No scam phrases flagged in this session.")

    # ── Full transcript table ─────────────────────────────────
    st.markdown("#### Full Session Transcript")
    display = df[["time", "source", "level", "score", "text"]].copy()
    display["score"] = display["score"].map("{:.1%}".format)
    st.dataframe(display, use_container_width=True, hide_index=True, height=300)


# ─── PAGE: Settings ───────────────────────────────────────────

def page_settings():
    st.markdown("## ⚙️ Settings")

    st.markdown("#### Privacy & Data")
    if st.button("🗑️ Clear All Session Data", type="secondary"):
        st.session_state.transcript_log  = []
        st.session_state.risk_history    = deque(maxlen=120)
        st.session_state.current_score   = 0.0
        st.session_state.current_level   = "safe"
        st.session_state.current_phrases = []
        st.session_state.alert_count     = {"critical": 0, "high": 0, "medium": 0}
        st.success("Session data cleared.")

    if st.button("🔄 Revoke Consent & Reset", type="secondary"):
        for key in list(st.session_state.keys()):
            del st.session_state[key]
        st.rerun()

    st.divider()
    st.markdown("#### BERT Model")

    col_a, col_b = st.columns(2)
    with col_a:
        st.markdown(f"**Model**")
        st.code(BERT_MODEL_NAME)
    with col_b:
        st.markdown("**Device**")
        device = st.session_state.get("model_device", "not loaded")
        if "cuda" in device:
            st.success(f"⚡ {device.upper()}")
        elif device == "not loaded":
            st.warning("Not loaded yet")
        else:
            st.info(f"🖥️ {device.upper()}")

    if METRICS_PATH.exists():
        with open(METRICS_PATH) as f:
            metrics = json.load(f)
        c1, c2, c3 = st.columns(3)
        with c1: st.metric("Best Val F1",  f"{metrics.get('f1', 0):.4f}")
        with c2: st.metric("Epochs",        metrics.get("epochs", "—"))
        with c3: st.metric("Trained on",    metrics.get("device", "—"))
    else:
        st.info("Model not yet fine-tuned. Click ▶ Start Monitoring to begin.")

    st.divider()
    st.markdown("#### Fine-tune BERT on Your Data")
    st.caption(
        "Provide your labelled CSV path to fine-tune BERT. "
        "Columns: `text` (str), `label` (int: 1=scam, 0=not scam)."
    )

    retrain_csv = st.text_input(
        "Path to labelled CSV",
        placeholder="data/scam_transcripts.csv",
        key="retrain_csv_path",
    )

    if st.button("🔁 Retrain BERT", type="primary"):
        if not retrain_csv:
            st.error("Please provide a CSV path before retraining.")
        elif not Path(retrain_csv).exists():
            st.error(f"File not found: `{retrain_csv}`")
        else:
            import nlp_scorer as _nm
            _nm._scorer = None      # Reset singleton — forces fresh load

            scorer = get_scorer()
            with st.spinner("Fine-tuning BERT... (3–8 min GPU / ~30 min CPU)"):
                scorer.load(csv_path=retrain_csv, force_retrain=True)

            st.session_state.model_loaded = True
            st.session_state.model_device = scorer.device_str
            st.success(
                f"Fine-tuning complete!  Device: {scorer.device_str}"
            )
            st.rerun()

    st.divider()
    st.markdown("#### Detection Thresholds")
    st.caption("Thresholds applied to the rolling 5-chunk average score.")
    threshold_data = {
        "Level":     ["🟡 Medium", "🟠 High", "🔴 Critical"],
        "Min Score": ["35%",        "60%",      "80%"],
        "Action":    [
            "Gentle warning shown",
            "Full alert banner",
            "Critical alert + disconnect prompt",
        ],
    }
    import pandas as pd
    st.dataframe(
        pd.DataFrame(threshold_data),
        use_container_width=True,
        hide_index=True,
    )


# ─── PAGE: About ──────────────────────────────────────────────

def page_about():
    st.markdown("## ℹ️ About DIGISHIELD")
    st.markdown("""
    **DIGISHIELD** is a real-time digital arrest scam detection system
    powered by a fine-tuned multilingual BERT model.

    ### Full Pipeline
    ```
    System Audio (loopback)  ┐
                              ├──► audio_queue
    Microphone (optional)    ┘        │
                                      ▼
                             faster-whisper (small)
                             CUDA float16 / CPU int8
                                      │
                               TranscriptBus
                               (thread-safe queue)
                                      │
                              clean() + tokenise()
                      distilbert-base-multilingual-cased
                                      │
                         Fine-tuned Linear(768 → 2)
                               + Softmax
                                      │
                      ┌───────────────┴──────────────────┐
                   P(scam)                          P(benign)
                      │
                 Attention weights
            (CLS → token, last layer avg)
                      │
            High-attention tokens decoded
            → matched to scam phrase lexicon
                      │
                 Duration amplifier
          (long calls with elevated score → +8–15%)
                      │
              Rolling 5-chunk average
                      │
               Risk Level + Alert
    ```

    ### Why distilbert-base-multilingual-cased?
    | Property | Detail |
    |----------|--------|
    | Architecture | DistilBERT (distilled from mBERT) |
    | Parameters | ~135M — 40% smaller than full mBERT |
    | Languages | 104 languages incl. Hindi + English |
    | Code-switching | ✅ Handles Hinglish naturally |
    | Inference | ~50ms GPU / ~200ms CPU per chunk |
    | Attention output | ✅ Used for phrase highlighting |
    | Fine-tuning time | ~5 min GPU / ~30 min CPU |

    ### Risk Levels
    | Level | Smoothed Score | UI Action |
    |-------|---------------|-----------|
    | ✅ Safe | < 35% | No alert |
    | 🟡 Medium | 35–60% | Subtle warning |
    | 🟠 High | 60–80% | Alert banner |
    | 🔴 Critical | > 80% | Full-screen alert + disconnect prompt |

    ### Privacy
    - No audio files saved — raw PCM processed in memory only
    - No transcripts persisted — session data in browser memory only
    - BERT + Whisper run **100% locally** — no external API calls
    - No PII collected

    ### Emergency Contacts
    - 🚨 **National Cyber Crime Helpline:** 1930
    - 🌐 **Report online:** cybercrime.gov.in
    """)


# ─── Monitoring Controls ──────────────────────────────────────

def _start_monitoring(csv_path: Optional[str] = None):
    scorer = get_scorer()

    if not st.session_state.model_loaded:
        st.session_state.model_loading = True
        with st.spinner(
            "🧠 Loading BERT model (distilbert-multilingual)...  "
            "**First run:** downloads ~280 MB + fine-tunes "
            "(3–8 min GPU / ~30 min CPU).  "
            "**Subsequent runs:** loads from checkpoint in seconds."
        ):
            scorer.load(csv_path=csv_path)

        st.session_state.model_loaded  = True
        st.session_state.model_loading = False
        st.session_state.model_device  = scorer.device_str

    scorer.reset_buffer()

    stt = STTSession()
    stt.start()

    st.session_state.stt_session     = stt
    st.session_state.monitoring      = True
    st.session_state.call_start_time = time.time()
    st.session_state.session_start   = datetime.now()
    st.session_state.alert_count     = {"critical": 0, "high": 0, "medium": 0}
    st.session_state.transcript_log  = []
    st.session_state.risk_history    = deque(maxlen=120)
    st.session_state.current_score   = 0.0
    st.session_state.current_level   = "safe"


def _stop_monitoring():
    stt: STTSession = st.session_state.stt_session
    if stt:
        stt.stop()
    st.session_state.monitoring    = False
    st.session_state.stt_session   = None


# ─── Main Router ──────────────────────────────────────────────

def main():
    page = render_sidebar()

    if page == "Live Monitor":
        page_live_monitor()
    elif page == "Analytics":
        page_analytics()
    elif page == "Settings":
        page_settings()
    elif page == "About":
        page_about()


if __name__ == "__main__":
    main()
