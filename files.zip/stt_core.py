# ============================================================
# DIGISHIELD — stt_core.py
# Real-time STT engine adapted from your original audio code.
# Runs entirely as background threads — no browser audio needed.
#
# Changes from your original:
#   1. Transcripts are pushed to a shared TranscriptBus instead
#      of print() — Streamlit reads from this bus.
#   2. stop_event is passed in so Streamlit controls lifecycle.
#   3. CPU fallback added (int8) when CUDA is unavailable.
#   4. Source tagging preserved: [SYSTEM] / [MIC]
# ============================================================

import queue
import threading
import time
import numpy as np

try:
    import soundcard as sc
    SOUNDCARD_AVAILABLE = True
except Exception:
    SOUNDCARD_AVAILABLE = False

try:
    import sounddevice as sd
    SOUNDDEVICE_AVAILABLE = True
except Exception:
    SOUNDDEVICE_AVAILABLE = False

from faster_whisper import WhisperModel

SAMPLE_RATE  = 16000
BLOCK_SIZE   = 4096
BUFFER_SECS  = 4          # Flush buffer every 4 seconds (matches your code)
SILENCE_RMS  = 0.01       # Your silence threshold


# ─── Transcript Bus ──────────────────────────────────────────
# Thread-safe queue that the Streamlit UI reads from.
# Each item: { "source": "SYSTEM"|"MIC", "text": str, "ts": float }

class TranscriptBus:
    def __init__(self, maxsize: int = 500):
        self._q = queue.Queue(maxsize=maxsize)

    def put(self, source: str, text: str):
        try:
            self._q.put_nowait({
                "source": source,
                "text": text.strip(),
                "ts": time.time(),
            })
        except queue.Full:
            pass  # Drop oldest-ish — never block the transcription thread

    def drain(self) -> list[dict]:
        """Pull all pending items. Called by Streamlit on each rerun."""
        items = []
        while not self._q.empty():
            try:
                items.append(self._q.get_nowait())
            except queue.Empty:
                break
        return items

    def empty(self) -> bool:
        return self._q.empty()


# ─── Model Loader ─────────────────────────────────────────────

def load_whisper_model(device: str = "auto") -> WhisperModel:
    """
    Load faster-whisper model with CUDA if available, else CPU int8.
    Matches your original: model = WhisperModel("small", device="cuda", ...)
    """
    import torch
    if device == "auto":
        use_cuda = torch.cuda.is_available()
    else:
        use_cuda = (device == "cuda")

    if use_cuda:
        model = WhisperModel("small", device="cuda", compute_type="float16")
        print("[DIGISHIELD] Whisper loaded on CUDA (float16)")
    else:
        model = WhisperModel("small", device="cpu", compute_type="int8")
        print("[DIGISHIELD] Whisper loaded on CPU (int8 fallback)")

    return model


# ─── Audio Capture Threads ────────────────────────────────────

def record_system_audio(audio_queue: queue.Queue,
                         stop_event: threading.Event):
    """
    Captures system speaker loopback audio.
    Direct port of your record_system_audio() function.
    """
    if not SOUNDCARD_AVAILABLE:
        print("[DIGISHIELD] soundcard not available — system audio disabled.")
        return

    try:
        speaker  = sc.default_speaker()
        loopback = sc.get_microphone(
            id=str(speaker.name), include_loopback=True
        )
        print(f"[DIGISHIELD] System audio capture started ({speaker.name})")

        with loopback.recorder(samplerate=SAMPLE_RATE, channels=1) as recorder:
            while not stop_event.is_set():
                data = recorder.record(numframes=BLOCK_SIZE)
                audio_queue.put(("SYSTEM", data.copy()))

    except Exception as e:
        print(f"[DIGISHIELD] System audio error: {e}")

    print("[DIGISHIELD] System audio stopped.")


def record_mic(audio_queue: queue.Queue,
               stop_event: threading.Event,
               mic_enabled_flag: threading.Event):
    """
    Captures microphone audio.
    Direct port of your record_mic() function.
    mic_enabled_flag replaces your global mic_enabled bool.
    """
    if not SOUNDDEVICE_AVAILABLE:
        print("[DIGISHIELD] sounddevice not available — mic disabled.")
        return

    try:
        print("[DIGISHIELD] Mic thread ready.")
        with sd.InputStream(samplerate=SAMPLE_RATE,
                            channels=1,
                            blocksize=BLOCK_SIZE) as stream:
            while not stop_event.is_set():
                if mic_enabled_flag.is_set():
                    data, _ = stream.read(BLOCK_SIZE)
                    audio_queue.put(("MIC", data.copy()))
                else:
                    time.sleep(0.1)

    except Exception as e:
        print(f"[DIGISHIELD] Mic error: {e}")

    print("[DIGISHIELD] Microphone stopped.")


# ─── Transcription Thread ─────────────────────────────────────

def transcribe_audio(audio_queue: queue.Queue,
                     stop_event: threading.Event,
                     bus: TranscriptBus,
                     model: WhisperModel):
    """
    Transcription worker. Direct port of your transcribe_audio().
    Pushes results to TranscriptBus instead of print().
    """
    buffer = np.zeros((0, 1), dtype=np.float32)
    print("[DIGISHIELD] Transcription thread started.")

    while not stop_event.is_set():
        try:
            source, chunk = audio_queue.get(timeout=1)
            buffer = np.concatenate((buffer, chunk))

            if len(buffer) < SAMPLE_RATE * BUFFER_SECS:
                continue   # Keep buffering until 4 seconds

            # ── Silence filter (your exact logic) ────────────
            energy = np.sqrt(np.mean(buffer ** 2))
            if energy < SILENCE_RMS:
                buffer = np.zeros((0, 1), dtype=np.float32)
                continue

            # ── Transcribe ────────────────────────────────────
            segments, _ = model.transcribe(
                buffer.flatten(),
                language="en",
                vad_filter=True,   # Your VAD filter preserved
            )

            for segment in segments:
                text = segment.text.strip()
                if text:
                    print(f"[{source}] {text}")    # Keep your console output
                    bus.put(source=source, text=text)

            buffer = np.zeros((0, 1), dtype=np.float32)

        except queue.Empty:
            continue
        except Exception as e:
            print(f"[DIGISHIELD] Transcription error: {e}")
            buffer = np.zeros((0, 1), dtype=np.float32)

    print("[DIGISHIELD] Transcription stopped.")


# ─── Session Controller ───────────────────────────────────────

class STTSession:
    """
    Manages the full lifecycle of audio capture + transcription.
    Streamlit stores one instance in st.session_state.
    """

    def __init__(self):
        self.bus           = TranscriptBus()
        self.audio_queue   = queue.Queue()
        self.stop_event    = threading.Event()
        self.mic_enabled   = threading.Event()   # Replaces your global bool
        self.model         = None
        self._threads: list[threading.Thread] = []
        self.running       = False

    def start(self):
        if self.running:
            return

        if self.model is None:
            self.model = load_whisper_model(device="auto")

        self.stop_event.clear()
        self.running = True

        # Mirror your thread setup exactly
        threads = [
            threading.Thread(target=record_system_audio,
                             args=(self.audio_queue, self.stop_event),
                             daemon=True, name="system-audio"),
            threading.Thread(target=record_mic,
                             args=(self.audio_queue, self.stop_event,
                                   self.mic_enabled),
                             daemon=True, name="mic-audio"),
            threading.Thread(target=transcribe_audio,
                             args=(self.audio_queue, self.stop_event,
                                   self.bus, self.model),
                             daemon=True, name="transcriber"),
        ]

        for t in threads:
            t.start()

        self._threads = threads
        print("[DIGISHIELD] STT session started.")

    def stop(self):
        if not self.running:
            return
        self.stop_event.set()
        self.running = False
        # Threads are daemon — they'll exit when stop_event fires
        print("[DIGISHIELD] STT session stopping...")

    def toggle_mic(self) -> bool:
        """Toggle mic on/off. Returns new state (True = ON)."""
        if self.mic_enabled.is_set():
            self.mic_enabled.clear()
            print("[DIGISHIELD] Mic OFF")
            return False
        else:
            self.mic_enabled.set()
            print("[DIGISHIELD] Mic ON")
            return True

    @property
    def mic_is_on(self) -> bool:
        return self.mic_enabled.is_set()
