# DIGISHIELD — Streamlit Web App

Real-time digital arrest scam detection running entirely in your browser.
No Flutter. No mobile. Just `streamlit run app.py`.

---

## File Structure

```
digishield_streamlit/
├── app.py            ← Main Streamlit UI (run this)
├── stt_core.py       ← Your audio code, wrapped for Streamlit threading
├── nlp_scorer.py     ← TF-IDF + Logistic Regression scorer
├── requirements.txt
└── model_artifacts/  ← Created automatically on first run
    ├── digishield_model.pkl
    ├── digishield_vectorizer.pkl
    └── metrics.json
```

---

## Setup

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. If you have a CUDA GPU (faster Whisper):
pip install torch --index-url https://download.pytorch.org/whl/cu118

# 3. Run
streamlit run app.py
```

App opens at **http://localhost:8501**

---

## How It Works

```
System Audio (loopback)  ┐
                          ├─► audio_queue ─► faster-whisper ─► TranscriptBus
Microphone (optional)    ┘                                          │
                                                               nlp_scorer
                                                                    │
                                                         risk_score + level
                                                                    │
                                                          Streamlit UI alert
```

- **stt_core.py** is a direct adaptation of your original audio script.
  All your logic is preserved: system loopback, mic toggle, VAD filter,
  silence threshold, 4-second buffer, source tagging ([SYSTEM] / [MIC]).

- **Transcripts flow into a `TranscriptBus`** (thread-safe queue) instead
  of `print()`. Streamlit drains this queue on every 3-second auto-refresh.

- **No audio ever leaves your machine.** Whisper runs locally.

---

## Mic Toggle

In the sidebar, click **"🔇 Mic: OFF"** to enable your microphone.
System audio (loopback) is always active when monitoring is running.

---

## Model

On first run, the app auto-trains a TF-IDF + Logistic Regression model
on a synthetic scam dataset (~1200 examples). This takes ~5 seconds.

To use your own labelled data:
1. Go to ⚙️ Settings → Retrain Model
2. Upload a CSV with columns: `text`, `label` (1=scam, 0=benign)
3. Click Retrain Now

---

## Pages

| Page | What it shows |
|------|--------------|
| 🔴 Live Monitor | Real-time risk gauge, transcript feed, alerts |
| 📊 Analytics | Risk breakdown charts, flagged phrase frequency |
| ⚙️ Settings | Retrain model, clear data, revoke consent |
| ℹ️ About | Pipeline diagram, risk levels, emergency contacts |

---

## Emergency Contacts (India)

- **National Cyber Crime Helpline:** 1930
- **Online reporting:** cybercrime.gov.in
